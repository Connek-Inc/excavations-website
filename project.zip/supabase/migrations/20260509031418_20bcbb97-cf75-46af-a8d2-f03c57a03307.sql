ALTER TABLE public.soumissions ADD COLUMN IF NOT EXISTS signing_token uuid UNIQUE DEFAULT gen_random_uuid();
UPDATE public.soumissions SET signing_token = gen_random_uuid() WHERE signing_token IS NULL;
CREATE INDEX IF NOT EXISTS soumissions_signing_token_idx ON public.soumissions(signing_token);