-- Enum for signature role
DO $$ BEGIN
  CREATE TYPE public.signature_role AS ENUM ('client', 'entrepreneur');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE public.signatures (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  soumission_id UUID NOT NULL REFERENCES public.soumissions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  role public.signature_role NOT NULL,
  nom_signataire TEXT NOT NULL,
  signature_data TEXT NOT NULL,
  signed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_signatures_soumission ON public.signatures(soumission_id);
CREATE INDEX idx_signatures_role ON public.signatures(soumission_id, role);

ALTER TABLE public.signatures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own signatures select" ON public.signatures
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "own signatures insert" ON public.signatures
  FOR INSERT WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM public.soumissions s
      WHERE s.id = soumission_id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY "own signatures delete" ON public.signatures
  FOR DELETE USING (auth.uid() = user_id);
