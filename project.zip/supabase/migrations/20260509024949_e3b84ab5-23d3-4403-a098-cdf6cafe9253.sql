
CREATE SEQUENCE IF NOT EXISTS public.soumission_numero_seq START WITH 513 INCREMENT BY 1;

CREATE OR REPLACE FUNCTION public.assign_soumission_numero()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  yr text;
  n  bigint;
BEGIN
  IF NEW.numero IS NULL OR btrim(NEW.numero) = '' THEN
    yr := to_char(COALESCE(NEW.date_soumission, CURRENT_DATE), 'YYYY');
    n  := nextval('public.soumission_numero_seq');
    NEW.numero := yr || '-' || lpad(n::text, 5, '0');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assign_soumission_numero ON public.soumissions;
CREATE TRIGGER trg_assign_soumission_numero
BEFORE INSERT ON public.soumissions
FOR EACH ROW
EXECUTE FUNCTION public.assign_soumission_numero();
