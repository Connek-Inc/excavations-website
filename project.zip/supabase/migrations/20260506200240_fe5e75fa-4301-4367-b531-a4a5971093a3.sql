ALTER TABLE public.soumissions
  ADD COLUMN IF NOT EXISTS duplicated_from UUID REFERENCES public.soumissions(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS duplicated_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_soumissions_duplicated_from
  ON public.soumissions(duplicated_from);
