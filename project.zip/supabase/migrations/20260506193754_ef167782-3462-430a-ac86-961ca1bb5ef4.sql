
-- Profiles + soumissions tables
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile read" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

CREATE TYPE soumission_statut AS ENUM ('Brouillon','Envoyée','Acceptée','Signée');
CREATE TYPE amenagement_type AS ENUM ('non_inclus','inclus','partiellement','a_preciser');

CREATE TABLE public.soumissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  numero TEXT,
  client_nom TEXT NOT NULL DEFAULT '',
  client_adresse TEXT NOT NULL DEFAULT '',
  projet_adresse TEXT NOT NULL DEFAULT '',
  date_soumission DATE NOT NULL DEFAULT CURRENT_DATE,
  description TEXT NOT NULL DEFAULT '',
  pieds_lineaires INTEGER NOT NULL DEFAULT 0,
  cheminees INTEGER NOT NULL DEFAULT 0,
  pompes INTEGER NOT NULL DEFAULT 0,
  drain_gouttiere BOOLEAN NOT NULL DEFAULT false,
  amenagement amenagement_type NOT NULL DEFAULT 'non_inclus',
  amenagement_precision TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  sous_total NUMERIC(12,2) NOT NULL DEFAULT 0,
  modalites JSONB NOT NULL DEFAULT '[{"label":"À la signature du contrat","pourcentage":60},{"label":"En cours de travaux","pourcentage":30},{"label":"À la fin des travaux","pourcentage":10}]'::jsonb,
  statut soumission_statut NOT NULL DEFAULT 'Brouillon',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.soumissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own soumissions select" ON public.soumissions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "own soumissions insert" ON public.soumissions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own soumissions update" ON public.soumissions FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "own soumissions delete" ON public.soumissions FOR DELETE USING (auth.uid() = user_id);

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER soumissions_updated BEFORE UPDATE ON public.soumissions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email) VALUES (NEW.id, NEW.email);
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
