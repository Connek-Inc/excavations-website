
ALTER TABLE public.soumissions
  ADD COLUMN entrepreneur_nom TEXT,
  ADD COLUMN entrepreneur_signature TEXT,
  ADD COLUMN entrepreneur_signed_at TIMESTAMPTZ,
  ADD COLUMN client_signataire_nom TEXT,
  ADD COLUMN client_signature TEXT,
  ADD COLUMN client_signed_at TIMESTAMPTZ,
  ADD COLUMN sent_at TIMESTAMPTZ;
