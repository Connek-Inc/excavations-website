ALTER TABLE public.soumissions
ADD COLUMN IF NOT EXISTS articles jsonb NOT NULL DEFAULT '[]'::jsonb;