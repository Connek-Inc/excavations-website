ALTER TABLE public.soumissions
  ADD COLUMN IF NOT EXISTS travaux_custom text,
  ADD COLUMN IF NOT EXISTS prix_custom text;