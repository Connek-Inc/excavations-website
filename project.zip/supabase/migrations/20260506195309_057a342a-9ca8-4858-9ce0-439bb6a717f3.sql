INSERT INTO storage.buckets (id, name, public)
VALUES ('signatures', 'signatures', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "signatures owner read" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'signatures' AND auth.uid()::text = (storage.foldername(name))[1]
  );
CREATE POLICY "signatures owner insert" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'signatures' AND auth.uid()::text = (storage.foldername(name))[1]
  );
CREATE POLICY "signatures owner delete" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'signatures' AND auth.uid()::text = (storage.foldername(name))[1]
  );
