import { useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

type UseAuthOptions = {
  ensureAnonymous?: boolean;
  timeoutMs?: number;
};

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      window.setTimeout(() => reject(new Error("Auth timeout")), timeoutMs);
    }),
  ]);
}

export function useAuth(options: UseAuthOptions = {}) {
  const { ensureAnonymous = false, timeoutMs = 5000 } = options;
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      if (cancelled) return;
      setSession(s);
      setUser(s?.user ?? null);
      setLoading(false);
    });
    withTimeout(supabase.auth.getSession(), timeoutMs).then(async ({ data }) => {
      if (cancelled) return;
      let current = data.session;
      if (!current && ensureAnonymous) {
        const { data: anon, error } = await withTimeout(supabase.auth.signInAnonymously(), timeoutMs);
        if (cancelled) return;
        if (error) console.error("[auth] signInAnonymously failed:", error.message);
        current = anon.session ?? null;
      }
      setSession(current);
      setUser(current?.user ?? null);
      setLoading(false);
    }).catch((e) => {
      if (cancelled) return;
      console.error("[auth] getSession failed:", e);
      setLoading(false);
    });
    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, [ensureAnonymous, timeoutMs]);

  return { session, user, loading };
}