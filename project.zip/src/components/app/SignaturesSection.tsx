import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { SignaturePad, type SignaturePadHandle } from "./SignaturePad";
import { Eraser, PenLine, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { Tables } from "@/integrations/supabase/types";

type Signature = Tables<"signatures">;
type Role = "client" | "entrepreneur";

export function SignaturesSection({ soumissionId, userId, onChanged }: {
  soumissionId: string | null;
  userId: string;
  onChanged?: () => void;
}) {
  const [items, setItems] = useState<Signature[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    if (!soumissionId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("signatures")
      .select("*")
      .eq("soumission_id", soumissionId)
      .order("signed_at", { ascending: false });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setItems(data ?? []);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [soumissionId]);

  const remove = async (id: string) => {
    const { error } = await supabase.from("signatures").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Signature supprimée");
    await load();
    onChanged?.();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>6. Signatures</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!soumissionId ? (
          <p className="text-sm text-muted-foreground">
            Sauvegardez la soumission avant d'ajouter des signatures.
          </p>
        ) : (
          <>
            <div className="grid gap-6 md:grid-cols-2">
              <SignatureForm role="entrepreneur" soumissionId={soumissionId} userId={userId} onSaved={() => { load(); onChanged?.(); }} />
              <SignatureForm role="client" soumissionId={soumissionId} userId={userId} onSaved={() => { load(); onChanged?.(); }} />
            </div>

            <div className="space-y-2">
              <Label className="text-sm">Historique</Label>
              {loading && <p className="text-sm text-muted-foreground">Chargement…</p>}
              {!loading && items.length === 0 && (
                <p className="text-sm text-muted-foreground">Aucune signature enregistrée.</p>
              )}
              <div className="space-y-2">
                {items.map((s) => (
                  <div key={s.id} className="flex items-center gap-3 rounded-md border p-2">
                    <Badge variant={s.role === "entrepreneur" ? "default" : "secondary"}>
                      {s.role === "entrepreneur" ? "Entrepreneur" : "Client"}
                    </Badge>
                    <img src={s.signature_data} alt="" className="h-12 w-32 object-contain" />
                    <div className="flex-1 text-sm">
                      <div className="font-medium">{s.nom_signataire}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(s.signed_at).toLocaleString("fr-CA")}
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => remove(s.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function SignatureForm({ role, soumissionId, userId, onSaved }: {
  role: Role;
  soumissionId: string;
  userId: string;
  onSaved: () => void;
}) {
  const padRef = useRef<SignaturePadHandle>(null);
  const [nom, setNom] = useState("");
  const [busy, setBusy] = useState(false);

  const save = async () => {
    if (!nom.trim()) { toast.error("Nom du signataire requis."); return; }
    if (padRef.current?.isEmpty()) { toast.error("Veuillez signer dans la zone."); return; }
    setBusy(true);
    const dataUrl = padRef.current!.toDataURL();
    const { error } = await supabase.from("signatures").insert({
      soumission_id: soumissionId,
      user_id: userId,
      role,
      nom_signataire: nom.trim(),
      signature_data: dataUrl,
      user_agent: navigator.userAgent,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    // Mirror latest into soumissions snapshot for PDF + statut
    const now = new Date().toISOString();
    const patch = role === "entrepreneur"
      ? { entrepreneur_nom: nom.trim(), entrepreneur_signature: dataUrl, entrepreneur_signed_at: now }
      : { client_signataire_nom: nom.trim(), client_signature: dataUrl, client_signed_at: now };
    await supabase.from("soumissions").update(patch).eq("id", soumissionId);

    toast.success("Signature enregistrée");
    padRef.current?.clear();
    setNom("");
    onSaved();
  };

  return (
    <div className="space-y-2 rounded-md border p-3">
      <div className="flex items-center justify-between">
        <Label className="text-base">{role === "entrepreneur" ? "Entrepreneur" : "Client"}</Label>
      </div>
      <Input placeholder="Nom complet du signataire" value={nom} onChange={(e) => setNom(e.target.value)} />
      <SignaturePad ref={padRef} />
      <div className="flex gap-2">
        <Button type="button" variant="outline" size="sm" onClick={() => padRef.current?.clear()}>
          <Eraser className="mr-2 h-4 w-4" />Effacer
        </Button>
        <Button type="button" size="sm" disabled={busy} onClick={save}>
          <PenLine className="mr-2 h-4 w-4" />Enregistrer la signature
        </Button>
      </div>
    </div>
  );
}