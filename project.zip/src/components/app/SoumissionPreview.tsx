import { COMPANY, calcTotals, fmtMoney, type Modalite, type Article, articleTotal, articlesSubtotal } from "@/lib/company";
import { type Soumission } from "@/lib/contract-text";
import { SECTION_ORDER, getSectionText, type SectionsMap } from "@/lib/default-sections";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SignaturePad, type SignaturePadHandle } from "./SignaturePad";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Eraser, PenLine } from "lucide-react";
import { validateForSignature } from "@/lib/statut";

function S({ title, children, primary }: { title: string; children: React.ReactNode; primary?: boolean }) {
  return (
    <section className={primary ? "space-y-3 rounded-md border-2 border-primary/40 bg-primary/5 p-3 sm:p-4" : "space-y-1"}>
      <h3
        className={
          primary
            ? "border-l-[6px] border-primary pl-3 text-xl sm:text-2xl font-extrabold tracking-tight text-secondary"
            : "border-l-2 border-primary/60 pl-2 text-[11px] sm:text-sm font-semibold text-secondary"
        }
      >
        {title}
      </h3>
      <div className={primary ? "text-sm sm:text-base leading-relaxed text-foreground" : "text-[11px] sm:text-xs leading-snug text-foreground/80"}>
        {children}
      </div>
    </section>
  );
}

export function SoumissionPreview({
  s,
  signable,
  userId,
  onSigned,
}: {
  s: Soumission;
  signable?: boolean;
  userId?: string;
  onSigned?: () => void;
}) {
  const totals = calcTotals(Number(s.sous_total));
  const modalites = (s.modalites as unknown as Modalite[]) ?? [];
  const articles = (s.articles as unknown as Article[]) ?? [];
  const totalsFinal = articles.length > 0 ? calcTotals(articlesSubtotal(articles)) : totals;
  const sectionsMap = ((s as unknown as { sections?: SectionsMap }).sections ?? {}) as SectionsMap;
  return (
    <div className="mx-auto max-w-3xl rounded-lg border bg-card p-4 sm:p-8 shadow-sm">
      <header className="-mx-4 -mt-4 mb-6 bg-secondary px-4 py-5 text-secondary-foreground sm:-mx-8 sm:-mt-8 sm:px-8">
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="text-2xl font-black tracking-tight text-primary">{COMPANY.name.toUpperCase()}</div>
            <div className="mt-1 text-xs opacity-80">RBQ {COMPANY.rbq}  •  NEQ {COMPANY.neq}</div>
            <div className="text-xs opacity-80">{COMPANY.phone}  •  {COMPANY.website}</div>
          </div>
          <div className="flex h-14 w-14 items-center justify-center rounded-md bg-primary text-2xl font-black text-primary-foreground">
            ME
          </div>
        </div>
      </header>

      <h1 className="text-3xl font-bold">SOUMISSION-CONTRAT</h1>
      {s.numero && <div className="text-sm text-muted-foreground">N° {s.numero}</div>}

      <div className="mt-6 grid gap-4 rounded-md border bg-muted/20 p-4 sm:grid-cols-3">
        <div>
          <div className="text-xs font-bold uppercase text-muted-foreground">Client</div>
          <div className="font-semibold">{s.client_nom || "—"}</div>
          <div className="whitespace-pre-line text-xs text-muted-foreground">{s.client_adresse}</div>
        </div>
        <div>
          <div className="text-xs font-bold uppercase text-muted-foreground">Adresse du projet</div>
          <div className="whitespace-pre-line text-sm">{s.projet_adresse || "—"}</div>
        </div>
        <div>
          <div className="text-xs font-bold uppercase text-muted-foreground">Date</div>
          <div className="text-sm">{new Date(s.date_soumission).toLocaleDateString("fr-CA", { year: "numeric", month: "long", day: "numeric" })}</div>
        </div>
      </div>

      <div className="mt-6 space-y-5">
        {SECTION_ORDER.map((sec) => {
          const isPrimary = sec.key === "travaux" || sec.key === "prix";
          return (
            <S key={sec.key} title={`${sec.num}. ${sec.title}`} primary={isPrimary}>
              <p className="whitespace-pre-line">{getSectionText(sectionsMap, sec.key)}</p>
              {sec.key === "modalites" && modalites.length > 0 && (
                <ul className="mt-2 list-disc space-y-1 pl-5">
                  {modalites.map((m, i) => (
                    <li key={i}><strong>{m.pourcentage}%</strong> — {m.label} : <span className="font-medium">{fmtMoney((totalsFinal.total * m.pourcentage) / 100)}</span></li>
                  ))}
                </ul>
              )}
            </S>
          );
        })}
        {articles.length > 0 && (
          <S title="Détail des articles / propriétés">
            <div className="overflow-hidden rounded-md border">
              <div className="grid grid-cols-12 bg-secondary px-3 py-2 text-xs font-bold uppercase text-secondary-foreground">
                <div className="col-span-7">Description</div>
                <div className="col-span-1 text-right">Qté</div>
                <div className="col-span-2 text-right">Prix unit.</div>
                <div className="col-span-2 text-right">Total</div>
              </div>
              {articles.map((a, i) => (
                <div key={i} className="grid grid-cols-12 border-t px-3 py-2 text-sm">
                  <div className="col-span-7 whitespace-pre-line">{a.description || "—"}</div>
                  <div className="col-span-1 text-right">{a.quantite}</div>
                  <div className="col-span-2 text-right">{fmtMoney(Number(a.prix_unitaire) || 0)}</div>
                  <div className="col-span-2 text-right font-semibold">{fmtMoney(articleTotal(a))}</div>
                </div>
              ))}
            </div>
          </S>
        )}
        <S title="Détail des coûts">
          <div className="overflow-hidden rounded-md border">
            <div className="flex justify-between px-4 py-2"><span>Sous-total</span><span>{fmtMoney(totalsFinal.sousTotal)}</span></div>
            <div className="flex justify-between border-t px-4 py-2 text-muted-foreground"><span>TPS (5 %)</span><span>{fmtMoney(totalsFinal.tps)}</span></div>
            <div className="flex justify-between border-t px-4 py-2 text-muted-foreground"><span>TVQ (9,975 %)</span><span>{fmtMoney(totalsFinal.tvq)}</span></div>
            <div className="flex justify-between border-t bg-primary px-4 py-2 font-bold text-primary-foreground"><span>TOTAL</span><span>{fmtMoney(totalsFinal.total)}</span></div>
          </div>
        </S>
        {s.notes?.trim() && <S title="Notes supplémentaires"><p className="whitespace-pre-line">{s.notes}</p></S>}
        <S title="12. Signatures">
          <div className="grid gap-6 sm:grid-cols-2">
            <SignatureBlock
              role="entrepreneur"
              label="Entrepreneur"
              defaultName={s.entrepreneur_nom || `${COMPANY.dirigeant} — ${COMPANY.titre}`}
              caption={COMPANY.name}
              imageUrl={s.entrepreneur_signature}
              signedAt={s.entrepreneur_signed_at}
              soumissionId={s.id}
              userId={userId}
              signable={signable}
              onSigned={onSigned}
              parent={s}
            />
            <SignatureBlock
              role="client"
              label="Client"
              defaultName={s.client_signataire_nom || s.client_nom || ""}
              caption="Signature"
              imageUrl={s.client_signature}
              signedAt={s.client_signed_at}
              soumissionId={s.id}
              userId={userId}
              signable={signable}
              onSigned={onSigned}
              parent={s}
            />
          </div>
        </S>
      </div>
    </div>
  );
}

function SignatureBlock({
  role,
  label,
  defaultName,
  caption,
  imageUrl,
  signedAt,
  soumissionId,
  userId,
  signable,
  onSigned,
  parent,
}: {
  role: "entrepreneur" | "client";
  label: string;
  defaultName: string;
  caption: string;
  imageUrl: string | null;
  signedAt: string | null;
  soumissionId: string;
  userId?: string;
  signable?: boolean;
  onSigned?: () => void;
  parent: Soumission;
}) {
  const padRef = useRef<SignaturePadHandle>(null);
  const [editing, setEditing] = useState(false);
  const [nom, setNom] = useState(defaultName);
  const [busy, setBusy] = useState(false);

  const dataUrlToBlob = (dataUrl: string) => {
    const [meta, b64] = dataUrl.split(",");
    const mime = /data:(.*?);base64/.exec(meta)?.[1] ?? "image/png";
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  };

  const save = async () => {
    if (!userId) { toast.error("Session requise."); return; }
    if (!nom.trim()) { toast.error("Nom du signataire requis."); return; }
    if (padRef.current?.isEmpty()) { toast.error("Veuillez signer dans la zone."); return; }
    const guard = validateForSignature(parent, role);
    if (guard) { toast.error(guard); return; }
    setBusy(true);
    const dataUrl = padRef.current!.toDataURL();
    const blob = dataUrlToBlob(dataUrl);
    const path = `${userId}/${soumissionId}/${role}-${Date.now()}.png`;
    const up = await supabase.storage.from("signatures").upload(path, blob, {
      contentType: "image/png",
      upsert: false,
    });
    if (up.error) { setBusy(false); toast.error(up.error.message); return; }
    const { data: signed } = await supabase.storage.from("signatures").createSignedUrl(path, 60 * 60 * 24 * 365);
    const url = signed?.signedUrl ?? dataUrl;
    const now = new Date().toISOString();

    const { error: insErr } = await supabase.from("signatures").insert({
      soumission_id: soumissionId,
      user_id: userId,
      role,
      nom_signataire: nom.trim(),
      signature_data: url,
      user_agent: navigator.userAgent,
    });
    if (insErr) { setBusy(false); toast.error(insErr.message); return; }

    const sigPatch = role === "entrepreneur"
      ? { entrepreneur_nom: nom.trim(), entrepreneur_signature: url, entrepreneur_signed_at: now }
      : { client_signataire_nom: nom.trim(), client_signature: url, client_signed_at: now };
    // Recompute statut after applying this signature
    const nextStatut =
      (role === "entrepreneur" && parent.client_signature) || (role === "client" && parent.entrepreneur_signature)
        ? "Signée"
        : role === "client"
          ? "Acceptée"
          : parent.statut;
    const { error: updErr } = await supabase
      .from("soumissions")
      .update({ ...sigPatch, statut: nextStatut })
      .eq("id", soumissionId);
    setBusy(false);
    if (updErr) { toast.error(updErr.message); return; }
    toast.success("Signature enregistrée");
    setEditing(false);
    onSigned?.();
  };

  return (
    <div>
      <div className="text-xs font-bold uppercase text-muted-foreground">{label}</div>
      {imageUrl && !editing ? (
        <img src={imageUrl} alt={`Signature ${label}`} className="h-20 object-contain" />
      ) : signable && editing ? (
        <div className="space-y-2">
          <Input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Nom complet" />
          <SignaturePad ref={padRef} />
          <div className="flex gap-2">
            <Button type="button" size="sm" variant="outline" onClick={() => padRef.current?.clear()}>
              <Eraser className="mr-2 h-4 w-4" />Effacer
            </Button>
            <Button type="button" size="sm" onClick={save} disabled={busy}>
              <PenLine className="mr-2 h-4 w-4" />Enregistrer
            </Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => setEditing(false)}>Annuler</Button>
          </div>
        </div>
      ) : (
        <div className="h-20" />
      )}
      <div className="border-t pt-2 text-sm">{defaultName || "Nom"}</div>
      <div className="text-xs text-muted-foreground">{caption}</div>
      <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
        <span>Date : {signedAt ? new Date(signedAt).toLocaleDateString("fr-CA") : "____________________"}</span>
        {signable && !editing && (
          <Button type="button" size="sm" variant="link" className="h-auto p-0" onClick={() => setEditing(true)}>
            {imageUrl ? "Refaire la signature" : "Signer ici"}
          </Button>
        )}
      </div>
    </div>
  );
}