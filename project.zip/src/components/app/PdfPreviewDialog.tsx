import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, ExternalLink, Share2, X } from "lucide-react";
import { generatePdfBlob } from "@/lib/pdf";
import type { Tables } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjs.GlobalWorkerOptions.workerSrc = pdfjsWorker;

type Soumission = Tables<"soumissions">;

const isIOS = () =>
  typeof navigator !== "undefined" &&
  /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as unknown as { MSStream?: unknown }).MSStream;

export function PdfPreviewDialog({
  soumission,
  open,
  onOpenChange,
}: {
  soumission: Soumission | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [url, setUrl] = useState<string | null>(null);
  const [blob, setBlob] = useState<Blob | null>(null);
  const [filename, setFilename] = useState<string>("soumission.pdf");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [numPages, setNumPages] = useState(0);
  const [containerWidth, setContainerWidth] = useState(700);

  useEffect(() => {
    const compute = () => {
      const w = Math.min(window.innerWidth - 40, 900);
      setContainerWidth(Math.max(280, w));
    };
    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  }, []);

  useEffect(() => {
    if (!open || !soumission) return;
    let createdUrl: string | null = null;
    setLoading(true);
    setError(null);
    generatePdfBlob(soumission)
      .then(({ blob, url, filename }) => {
        setBlob(blob);
        setUrl(url);
        setFilename(filename);
        createdUrl = url;
      })
      .catch((e) => {
        const msg = (e as Error)?.message ?? "Erreur de génération du PDF";
        setError(msg);
        toast.error(msg);
      })
      .finally(() => setLoading(false));
    return () => {
      if (createdUrl) URL.revokeObjectURL(createdUrl);
      setUrl(null);
      setBlob(null);
      setError(null);
    };
  }, [open, soumission]);

  const onDownload = () => {
    if (!blob || !url) return;
    // iOS Safari ignores the `download` attribute on blob URLs and just navigates.
    // Open in a new tab so the user can use "Save to Files" / "Share".
    if (isIOS()) {
      window.open(url, "_blank");
      toast.message("Touchez l'icône Partager du navigateur pour enregistrer le PDF.");
      return;
    }
    try {
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch {
      window.open(url, "_blank");
    }
  };

  const onOpenTab = () => { if (url) window.open(url, "_blank"); };

  const onShare = async () => {
    if (!blob) return;
    const file = new File([blob], filename, { type: "application/pdf" });
    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    const shareData: ShareData = { files: [file], title: filename, text: filename };
    if (nav.canShare?.({ files: [file] })) {
      try {
        await navigator.share(shareData);
      } catch (e) {
        if ((e as Error).name !== "AbortError") {
          toast.error("Partage impossible. Téléchargement à la place.");
          onDownload();
        }
      }
      return;
    }
    // Fallback for desktop without file-share support.
    onDownload();
    toast.message("Partage non supporté sur cet appareil — PDF téléchargé.");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex h-[90vh] max-w-5xl flex-col p-0 sm:max-w-5xl">
        <DialogHeader className="border-b px-4 py-3">
          <DialogTitle className="text-base">Aperçu du PDF</DialogTitle>
        </DialogHeader>
        <div className="relative flex-1 overflow-hidden bg-muted">
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">
              Génération du PDF…
            </div>
          )}
          {error && !loading && (
            <div className="absolute inset-0 flex items-center justify-center px-6 text-center text-sm text-destructive">
              {error}
            </div>
          )}
          {blob && !error && (
            <div className="h-full overflow-auto bg-muted/40 py-4">
              <Document
                file={blob}
                onLoadSuccess={({ numPages }) => setNumPages(numPages)}
                onLoadError={(e) => setError(e.message)}
                loading={<div className="py-10 text-center text-sm text-muted-foreground">Chargement…</div>}
                className="flex flex-col items-center gap-4"
              >
                {Array.from({ length: numPages }, (_, i) => (
                  <div key={i} className="relative shadow-md">
                    <Page
                      pageNumber={i + 1}
                      width={containerWidth}
                      renderAnnotationLayer={false}
                      renderTextLayer={false}
                    />
                    <div className="absolute right-2 top-2 rounded bg-background/80 px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
                      {i + 1} / {numPages}
                    </div>
                  </div>
                ))}
              </Document>
            </div>
          )}
        </div>
        <DialogFooter className="flex flex-row flex-wrap justify-end gap-2 border-t px-4 py-3">
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
            <X className="mr-2 h-4 w-4" />Fermer
          </Button>
          <Button variant="outline" size="sm" onClick={onOpenTab} disabled={!url}>
            <ExternalLink className="mr-2 h-4 w-4" />Ouvrir
          </Button>
          <Button variant="outline" size="sm" onClick={onShare} disabled={!blob}>
            <Share2 className="mr-2 h-4 w-4" />Partager
          </Button>
          <Button size="sm" onClick={onDownload} disabled={!url}>
            <Download className="mr-2 h-4 w-4" />Télécharger
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}