import { Link } from "@tanstack/react-router";
import { COMPANY } from "@/lib/company";
import { Sparkles } from "lucide-react";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="border-b border-border bg-secondary text-secondary-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary font-black text-primary-foreground">
              ME
            </div>
            <div className="leading-tight">
              <div className="text-sm font-bold tracking-wide">{COMPANY.name}</div>
              <div className="text-xs opacity-70">Générateur de soumissions-contrats</div>
            </div>
          </Link>
          <a
            href="https://connek.io"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden items-center gap-1.5 rounded-full border border-white/20 bg-white/5 px-3 py-1 text-xs font-medium tracking-wide transition hover:bg-white/10 sm:inline-flex"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Powered by <span className="font-bold">CONNEK</span>
          </a>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">{children}</main>
      <footer className="border-t border-border bg-secondary/40">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
          <div>© {new Date().getFullYear()} {COMPANY.name}</div>
          <a
            href="https://connek.io"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 font-medium text-foreground hover:text-primary"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Powered by <span className="font-bold tracking-wide">CONNEK</span>
          </a>
        </div>
      </footer>
    </div>
  );
}