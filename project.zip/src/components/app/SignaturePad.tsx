import { useEffect, useImperativeHandle, useRef, forwardRef } from "react";

export type SignaturePadHandle = {
  clear: () => void;
  isEmpty: () => boolean;
  toDataURL: () => string;
};

export const SignaturePad = forwardRef<SignaturePadHandle, { initial?: string | null }>(
  function SignaturePad({ initial }, ref) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const drawing = useRef(false);
    const dirty = useRef(false);
    const last = useRef<{ x: number; y: number } | null>(null);

    useEffect(() => {
      const c = canvasRef.current;
      if (!c) return;
      const dpr = window.devicePixelRatio || 1;
      const rect = c.getBoundingClientRect();
      c.width = rect.width * dpr;
      c.height = rect.height * dpr;
      const ctx = c.getContext("2d")!;
      ctx.scale(dpr, dpr);
      ctx.lineWidth = 2;
      ctx.lineCap = "round";
      ctx.strokeStyle = "#000";
      if (initial) {
        const img = new Image();
        img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
        img.src = initial;
        dirty.current = true;
      }
    }, [initial]);

    const pos = (e: PointerEvent | React.PointerEvent) => {
      const c = canvasRef.current!;
      const r = c.getBoundingClientRect();
      return { x: (e as PointerEvent).clientX - r.left, y: (e as PointerEvent).clientY - r.top };
    };

    const start = (e: React.PointerEvent) => {
      e.preventDefault();
      drawing.current = true;
      last.current = pos(e);
      canvasRef.current!.setPointerCapture(e.pointerId);
    };
    const move = (e: React.PointerEvent) => {
      if (!drawing.current) return;
      const ctx = canvasRef.current!.getContext("2d")!;
      const p = pos(e);
      ctx.beginPath();
      ctx.moveTo(last.current!.x, last.current!.y);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
      last.current = p;
      dirty.current = true;
    };
    const end = () => { drawing.current = false; last.current = null; };

    useImperativeHandle(ref, () => ({
      clear: () => {
        const c = canvasRef.current!;
        const ctx = c.getContext("2d")!;
        ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, c.width, c.height); ctx.restore();
        dirty.current = false;
      },
      isEmpty: () => !dirty.current,
      toDataURL: () => canvasRef.current!.toDataURL("image/png"),
    }));

    return (
      <canvas
        ref={canvasRef}
        onPointerDown={start}
        onPointerMove={move}
        onPointerUp={end}
        onPointerCancel={end}
        className="h-40 w-full touch-none rounded-md border bg-background"
      />
    );
  },
);