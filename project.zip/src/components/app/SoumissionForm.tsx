import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import type { TablesInsert } from "@/integrations/supabase/types";
import { calcTotals, fmtMoney, type Modalite, type Article, articleTotal, articlesSubtotal } from "@/lib/company";
import { Plus, Trash2 } from "lucide-react";
import { SECTION_ORDER, DEFAULT_SECTIONS, type SectionsMap, type SectionKey } from "@/lib/default-sections";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export type FormState = Omit<TablesInsert<"soumissions">, "user_id" | "modalites" | "articles"> & {
  modalites: Modalite[];
  articles: Article[];
  sections: SectionsMap;
};

export function SoumissionForm({
  value,
  onChange,
}: {
  value: FormState;
  onChange: (v: FormState) => void;
}) {
  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => onChange({ ...value, [k]: v });
  const articles = value.articles ?? [];
  const hasArticles = articles.length > 0;
  const computedSousTotal = articlesSubtotal(articles);
  const sousTotal = hasArticles ? computedSousTotal : (Number(value.sous_total) || 0);
  const totals = calcTotals(sousTotal);

  const setModalite = (i: number, patch: Partial<Modalite>) => {
    const next = [...value.modalites] as Modalite[];
    next[i] = { ...next[i], ...patch };
    set("modalites", next);
  };
  const addModalite = () => set("modalites", [...value.modalites, { label: "", pourcentage: 0 }]);
  const removeModalite = (i: number) => set("modalites", value.modalites.filter((_, j) => j !== i));
  const totalPct = value.modalites.reduce((a, m) => a + (Number(m.pourcentage) || 0), 0);

  const updateArticles = (next: Article[]) => {
    onChange({ ...value, articles: next, sous_total: next.length > 0 ? articlesSubtotal(next) : value.sous_total });
  };
  const setArticle = (i: number, patch: Partial<Article>) => {
    const next = articles.map((a, j) => (j === i ? { ...a, ...patch } : a));
    updateArticles(next);
  };
  const addArticle = () =>
    updateArticles([...articles, { description: "", quantite: 1, prix_unitaire: 0 }]);
  const removeArticle = (i: number) => updateArticles(articles.filter((_, j) => j !== i));

  const sections = (value.sections ?? {}) as SectionsMap;
  const setSection = (k: SectionKey, v: string) =>
    onChange({ ...value, sections: { ...sections, [k]: v } });
  const resetSection = (k: SectionKey) => {
    const next = { ...sections };
    delete next[k];
    onChange({ ...value, sections: next });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader><CardTitle>1. Client & projet</CardTitle></CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2 md:col-span-2">
            <Label>Nom du client / compagnie *</Label>
            <Input value={value.client_nom ?? ""} onChange={(e) => set("client_nom", e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Adresse du client *</Label>
            <Textarea rows={2} value={value.client_adresse ?? ""} onChange={(e) => set("client_adresse", e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Adresse du projet *</Label>
            <Textarea rows={2} value={value.projet_adresse ?? ""} onChange={(e) => set("projet_adresse", e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Date de la soumission *</Label>
            <Input type="date" value={value.date_soumission ?? ""} onChange={(e) => set("date_soumission", e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Numéro (optionnel)</Label>
            <Input value={value.numero ?? ""} onChange={(e) => set("numero", e.target.value)} placeholder="ex: 2026-001" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>2. Notes internes (optionnel)</CardTitle></CardHeader>
        <CardContent>
          <Textarea
            rows={3}
            value={value.notes ?? ""}
            onChange={(e) => set("notes", e.target.value)}
            placeholder="Notes internes affichées en bas du PDF si remplies."
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>4. Articles / Propriétés</span>
            <span className="text-sm font-normal text-muted-foreground">
              {hasArticles ? `${articles.length} article(s)` : "Optionnel — multi-propriétés"}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Ajoutez un ou plusieurs articles (ex. drains français pour plusieurs propriétés). Si vide, le sous-total se saisit manuellement plus bas.
          </p>
          {articles.map((a, i) => (
            <div key={i} className="grid grid-cols-12 items-start gap-2 rounded-md border p-2">
              <div className="col-span-12 space-y-1 md:col-span-6">
                <Label className="text-xs">Description / Adresse</Label>
                <Textarea
                  rows={2}
                  value={a.description}
                  onChange={(e) => setArticle(i, { description: e.target.value })}
                  placeholder="ex: Drain français — 123 rue Principale"
                />
              </div>
              <div className="col-span-4 space-y-1 md:col-span-2">
                <Label className="text-xs">Quantité</Label>
                <Input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  value={a.quantite ? String(a.quantite) : ""}
                  onChange={(e) => setArticle(i, { quantite: e.target.value === "" ? 0 : Number(e.target.value) })}
                />
              </div>
              <div className="col-span-6 space-y-1 md:col-span-3">
                <Label className="text-xs">Prix unitaire (CAD)</Label>
                <Input
                  type="number"
                  inputMode="decimal"
                  min={0}
                  step="0.01"
                  value={a.prix_unitaire ? String(a.prix_unitaire) : ""}
                  onChange={(e) => setArticle(i, { prix_unitaire: e.target.value === "" ? 0 : Number(e.target.value) })}
                />
              </div>
              <div className="col-span-2 flex flex-col items-end justify-between gap-1 md:col-span-1">
                <Label className="text-xs">&nbsp;</Label>
                <Button variant="ghost" size="icon" onClick={() => removeArticle(i)} aria-label="Supprimer">
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
              <div className="col-span-12 text-right text-xs text-muted-foreground">
                Sous-total ligne : <strong>{fmtMoney(articleTotal(a))}</strong>
              </div>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={addArticle}>
            <Plus className="mr-2 h-4 w-4" />Ajouter un article
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>5. Prix</CardTitle></CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Sous-total avant taxes (CAD) *</Label>
            <Input
              type="number"
              inputMode="decimal"
              min={0}
              step="0.01"
              disabled={hasArticles}
              value={hasArticles ? String(computedSousTotal) : (value.sous_total ? String(value.sous_total) : "")}
              onChange={(e) => set("sous_total", e.target.value === "" ? 0 : Number(e.target.value))}
            />
            {hasArticles && (
              <p className="text-xs text-muted-foreground">Calculé automatiquement à partir des articles.</p>
            )}
          </div>
          <div className="rounded-md border bg-muted/30 p-4 text-sm">
            <div className="flex justify-between"><span>Sous-total</span><span>{fmtMoney(totals.sousTotal)}</span></div>
            <div className="flex justify-between text-muted-foreground"><span>TPS 5 %</span><span>{fmtMoney(totals.tps)}</span></div>
            <div className="flex justify-between text-muted-foreground"><span>TVQ 9,975 %</span><span>{fmtMoney(totals.tvq)}</span></div>
            <div className="mt-2 flex justify-between border-t pt-2 font-bold"><span>Total</span><span>{fmtMoney(totals.total)}</span></div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>6. Modalités de paiement</span>
            <span className={`text-sm font-normal ${totalPct === 100 ? "text-muted-foreground" : "text-destructive"}`}>
              Total : {totalPct} %
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {value.modalites.map((m, i) => (
            <div key={i} className="grid grid-cols-12 items-center gap-2">
              <Input className="col-span-8" placeholder="Description" value={m.label} onChange={(e) => setModalite(i, { label: e.target.value })} />
              <div className="col-span-3 flex items-center gap-1">
                <Input type="number" min={0} max={100} value={m.pourcentage} onChange={(e) => setModalite(i, { pourcentage: Number(e.target.value) })} />
                <span className="text-sm text-muted-foreground">%</span>
              </div>
              <Button variant="ghost" size="icon" className="col-span-1" onClick={() => removeModalite(i)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={addModalite}><Plus className="mr-2 h-4 w-4" />Ajouter une modalité</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between gap-2">
            <span>7. Contenu du contrat — sections éditables</span>
            <span className="text-sm font-normal text-muted-foreground">Toutes pré-remplies</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-3 text-xs text-muted-foreground">
            Chaque section ci-dessous est pré-remplie avec un texte standard. Modifiez ce que vous voulez : votre version remplacera le texte par défaut dans le PDF. Cliquez « Réinitialiser » pour revenir au texte standard.
          </p>
          <Accordion type="multiple" className="w-full">
            {SECTION_ORDER.map((s) => {
              const current = sections[s.key];
              const isCustom = typeof current === "string" && current.length > 0;
              const value = isCustom ? current! : DEFAULT_SECTIONS[s.key];
              const isPrimary = s.key === "travaux" || s.key === "prix";
              const rows = isPrimary
                ? Math.min(20, Math.max(10, value.split("\n").length + 2))
                : Math.min(6, Math.max(3, value.split("\n").length));
              return (
                <AccordionItem key={s.key} value={s.key}>
                  <AccordionTrigger className="text-left">
                    <span className="flex items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{s.num}</span>
                      <span className={isPrimary ? "font-bold text-primary" : "font-semibold"}>{s.title}</span>
                      {isPrimary && <span className="rounded bg-primary px-1.5 py-0.5 text-[10px] font-bold uppercase text-primary-foreground">Principal</span>}
                      {isCustom && <span className="rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-medium uppercase text-primary">Modifié</span>}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent>
                    <Textarea
                      rows={rows}
                      value={value}
                      onChange={(e) => setSection(s.key, e.target.value)}
                      className={isPrimary ? "text-sm" : "font-mono text-xs"}
                    />
                    <div className="mt-2 flex justify-end">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        disabled={!isCustom}
                        onClick={() => resetSection(s.key)}
                      >
                        Réinitialiser
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}