import type { Tables } from "@/integrations/supabase/types";
import type { Modalite } from "./company";
type S = Tables<"soumissions">;
export type Statut = S["statut"];

export function computeStatut(s: Pick<S, "entrepreneur_signature" | "client_signature" | "sent_at" | "statut">): S["statut"] {
  if (s.entrepreneur_signature && s.client_signature) return "Signée";
  if (s.client_signature) return "Acceptée";
  if (s.sent_at) return "Envoyée";
  return s.statut === "Acceptée" || s.statut === "Signée" ? s.statut : "Brouillon";
}

/** Allowed transitions. Brouillon → Envoyée → Acceptée → Signée (no skips, no rollback past Brouillon). */
const ALLOWED: Record<Statut, Statut[]> = {
  Brouillon: ["Brouillon", "Envoyée"],
  Envoyée: ["Envoyée", "Acceptée", "Brouillon"],
  Acceptée: ["Acceptée", "Signée"],
  Signée: ["Signée"],
};

export function canTransition(from: Statut, to: Statut): boolean {
  return ALLOWED[from]?.includes(to) ?? false;
}

/** Returns null if the soumission is complete enough to be sent to the client. */
export function validateForSend(s: Partial<S> & { modalites?: unknown }): string | null {
  if (!s.client_nom?.trim()) return "Le nom du client est requis.";
  if (!s.client_adresse?.trim()) return "L'adresse du client est requise.";
  if (!s.projet_adresse?.trim()) return "L'adresse du projet est requise.";
  if (!s.date_soumission) return "La date de la soumission est requise.";
  if (Number(s.sous_total ?? 0) <= 0) return "Le sous-total doit être supérieur à 0 $.";
  const mods = (s.modalites as Modalite[] | undefined) ?? [];
  if (mods.length === 0) return "Ajoutez au moins une modalité de paiement.";
  const total = mods.reduce((a, m) => a + (Number(m.pourcentage) || 0), 0);
  if (total !== 100) return `Les modalités doivent totaliser 100 % (actuellement ${total} %).`;
  if (mods.some((m) => !m.label?.trim())) return "Chaque modalité doit avoir une description.";
  return null;
}

/** Returns all missing/invalid fields that prevent sending the soumission to the client. */
export function listMissingForSend(s: Partial<S> & { modalites?: unknown }): string[] {
  const missing: string[] = [];
  if (!s.client_nom?.trim()) missing.push("Nom du client");
  if (!s.client_adresse?.trim()) missing.push("Adresse du client");
  if (!s.projet_adresse?.trim()) missing.push("Adresse du projet");
  if (!s.date_soumission) missing.push("Date de la soumission");
  if (Number(s.sous_total ?? 0) <= 0) missing.push("Sous-total supérieur à 0 $");
  const mods = (s.modalites as Modalite[] | undefined) ?? [];
  if (mods.length === 0) {
    missing.push("Au moins une modalité de paiement");
  } else {
    const total = mods.reduce((a, m) => a + (Number(m.pourcentage) || 0), 0);
    if (total !== 100) missing.push(`Modalités totalisant 100 % (actuellement ${total} %)`);
    if (mods.some((m) => !m.label?.trim())) missing.push("Description pour chaque modalité");
  }
  return missing;
}

/** Validates that a signature can be applied (the soumission must be valid + sent). */
export function validateForSignature(
  s: Pick<S, "statut" | "client_nom" | "client_adresse" | "projet_adresse" | "description" | "date_soumission" | "sous_total" | "amenagement" | "amenagement_precision" | "modalites" | "sent_at">,
  role: "client" | "entrepreneur",
): string | null {
  const err = validateForSend(s);
  if (err) return `Impossible de signer : ${err}`;
  if (!s.sent_at && s.statut === "Brouillon")
    return "La soumission doit d'abord être marquée comme envoyée au client.";
  if (role === "entrepreneur" && s.statut !== "Acceptée" && s.statut !== "Signée")
    return "L'entrepreneur signe après l'acceptation du client.";
  return null;
}