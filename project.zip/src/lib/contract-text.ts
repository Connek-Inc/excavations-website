import type { Tables } from "@/integrations/supabase/types";

export type Soumission = Tables<"soumissions">;

export function piedsLineairesText(n: number) {
  return `Excavation d'une tranchée d'environ ${n} pieds linéaires.`;
}
export function chemineesText(n: number) {
  if (!n || n <= 0) return "Aucune cheminée d'accès n'est incluse dans la présente soumission.";
  return `Installation de ${n} cheminée(s) d'accès (regards) en PVC rigide conforme.`;
}
export function drainGouttiereText(oui: boolean) {
  return oui
    ? "Installation et raccordement d'un système de drain de gouttière."
    : "Aucune installation ni raccordement d'un système de drain de gouttière n'est inclus dans la présente soumission.";
}
export function pompesText(n: number) {
  if (!n || n <= 0) return "Aucune pompe de puisard n'est incluse.";
  if (n === 1) return "Installation de 1 pompe de puisard avec connexion complète au système.";
  return `Installation de ${n} pompes de puisard avec connexion complète au système.`;
}
export function amenagementText(t: Soumission["amenagement"], precision?: string | null) {
  switch (t) {
    case "non_inclus":
      return "Toute détérioration du gazon, des arbustes, des clôtures, des entrées ou de tout autre aménagement existant est à la charge du client.";
    case "inclus":
      return "La remise en état de base de l'aménagement paysager directement touché par les travaux est incluse, selon les limites prévues à la présente soumission.";
    case "partiellement":
      return "La remise en état partielle de l'aménagement paysager est incluse uniquement pour les éléments précisés dans la présente soumission.";
    case "a_preciser":
      return precision?.trim() || "À préciser.";
  }
}

export function travauxTechniques(s: Soumission) {
  return [
    { titre: "3.1 Excavation", texte: piedsLineairesText(s.pieds_lineaires) },
    {
      titre: "3.2 Préparation et réparation de la fondation",
      texte:
        "Nettoyage complet du mur de fondation. Réparation des fissures apparentes et préparation de la surface en vue de l'imperméabilisation.",
    },
    {
      titre: "3.3 Imperméabilisation haute performance",
      texte:
        "Application d'un produit d'imperméabilisation haute performance sur la fondation, conforme aux normes en vigueur.",
    },
    {
      titre: "3.4 Membrane de protection",
      texte:
        "Installation d'une membrane de drainage et de protection sur le mur de fondation afin de protéger l'imperméabilisation et favoriser l'écoulement de l'eau vers le drain.",
    },
    {
      titre: "3.5 Installation du drain français",
      texte:
        "Installation d'un drain français neuf en PVC perforé, posé sur lit de pierre nette autour du périmètre de la fondation, conforme au Code de construction du Québec.",
    },
    {
      titre: "3.6 Système filtrant",
      texte:
        "Pose d'une membrane géotextile et recouvrement de pierre nette afin d'assurer la filtration et la longévité du drain français.",
    },
    { titre: "3.7 Cheminées d'accès", texte: chemineesText(s.cheminees) },
    { titre: "3.8 Système de pompage", texte: pompesText(s.pompes) },
    { titre: "3.9 Drainage des eaux pluviales", texte: drainGouttiereText(s.drain_gouttiere) },
    {
      titre: "3.10 Remblayage et finition",
      texte:
        "Remblayage de la tranchée avec les matériaux d'origine compactés par couches, et nivelage final du terrain à proximité de la zone de travail.",
    },
  ];
}

export const NORMES =
  "Les travaux sont exécutés conformément au Code de construction du Québec, aux normes RBQ en vigueur et aux règles de l'art applicables aux ouvrages d'excavation, de drainage et d'imperméabilisation.";

export const TRAVAUX_NON_INCLUS = [
  "Tout travail de plomberie intérieur non spécifiquement décrit dans la présente soumission.",
  "Réparation ou remplacement du revêtement extérieur de la fondation au-dessus du niveau du sol.",
  "Travaux d'électricité autres que le branchement de la pompe de puisard prévue.",
  "Réparation des fissures structurales majeures nécessitant une expertise en ingénierie.",
  "Tests de sol, étude géotechnique ou expertise d'ingénieur.",
  "Permis municipaux, frais d'arpentage et de localisation des services publics au-delà de l'appel standard à Info-Excavation.",
];

export const CONDITIONS_LIMITATIONS = [
  "L'entrepreneur n'est pas responsable des bris de services souterrains non identifiés par Info-Excavation ou non visibles avant l'excavation.",
  "L'accès au chantier doit être dégagé et sécuritaire pour la machinerie.",
  "Toute découverte imprévue (roc, contamination, structure enfouie, etc.) pourra entraîner un coût additionnel après entente écrite avec le client.",
];

export const GARANTIE =
  "Garantie de dix (10) ans sur l'installation du drain français et l'imperméabilisation, contre tout défaut de pose imputable à l'entrepreneur, conditionnellement à un usage normal et à l'absence de modifications par des tiers.";

export const EXCLUSIONS_RESPONSABILITE = [
  "L'entrepreneur ne peut être tenu responsable des infiltrations provenant d'une source autre que celle visée par les travaux (toiture, fenêtres, fissures structurales non traitées, etc.).",
  "Aucune garantie n'est offerte sur les éléments existants conservés (vieux drain, ancienne membrane, etc.) si le client refuse leur remplacement.",
];

export const ENGAGEMENTS =
  "Le client reconnaît avoir lu et compris l'ensemble de la présente soumission-contrat, en accepte les termes, conditions et modalités, et autorise Mini Excavation Érable Inc. à exécuter les travaux décrits ci-dessus.";