import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const tokenSchema = z.string().uuid();

export const getSoumissionByToken = createServerFn({ method: "GET" })
  .inputValidator((input: { token: string }) => ({ token: tokenSchema.parse(input.token) }))
  .handler(async ({ data }) => {
    const { data: row, error } = await supabaseAdmin
      .from("soumissions")
      .select("*")
      .eq("signing_token", data.token)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Lien de signature invalide ou expiré.");
    return { soumission: row };
  });

export const acceptAndSignByToken = createServerFn({ method: "POST" })
  .inputValidator((input: {
    token: string;
    nom: string;
    signature_data: string;
    user_agent?: string | null;
  }) =>
    z
      .object({
        token: tokenSchema,
        nom: z.string().trim().min(2).max(120),
        signature_data: z
          .string()
          .min(50)
          .max(2_000_000)
          .regex(/^data:image\/png;base64,/, "Signature invalide"),
        user_agent: z.string().max(500).nullish(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { data: row, error: getErr } = await supabaseAdmin
      .from("soumissions")
      .select("id, user_id, statut, client_signature, sent_at")
      .eq("signing_token", data.token)
      .maybeSingle();
    if (getErr) throw new Error(getErr.message);
    if (!row) throw new Error("Lien de signature invalide.");
    if (row.client_signature) throw new Error("Cette soumission a déjà été signée.");
    if (row.statut === "Brouillon" && !row.sent_at)
      throw new Error("La soumission n'est pas encore disponible pour signature.");

    const ip = getRequestHeader("x-forwarded-for") ?? null;
    const ua = data.user_agent ?? getRequestHeader("user-agent") ?? null;
    const now = new Date().toISOString();

    const newStatut = row.statut === "Signée" ? "Signée" : "Acceptée";

    const { error: upErr } = await supabaseAdmin
      .from("soumissions")
      .update({
        client_signataire_nom: data.nom,
        client_signature: data.signature_data,
        client_signed_at: now,
        statut: newStatut,
      })
      .eq("id", row.id);
    if (upErr) throw new Error(upErr.message);

    const { error: sigErr } = await supabaseAdmin.from("signatures").insert({
      soumission_id: row.id,
      user_id: row.user_id,
      role: "client",
      nom_signataire: data.nom,
      signature_data: data.signature_data,
      ip_address: ip,
      user_agent: ua,
    });
    if (sigErr) throw new Error(sigErr.message);

    return { ok: true, signed_at: now };
  });