import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { AppShell } from "@/components/app/AppShell";
import { SoumissionForm, type FormState } from "@/components/app/SoumissionForm";
import { SoumissionPreview } from "@/components/app/SoumissionPreview";
import { SignaturesSection } from "@/components/app/SignaturesSection";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert } from "@/integrations/supabase/types";
import { DEFAULT_MODALITES, type Modalite, type Article } from "@/lib/company";
import { ArrowLeft, Save, FileDown, Eye, Pencil, Send, RotateCcw, Copy, GitBranch, Link2 } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { canTransition, computeStatut, listMissingForSend, validateForSend } from "@/lib/statut";
import { CheckCircle2, AlertCircle } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const PdfPreviewDialog = lazy(() =>
  import("@/components/app/PdfPreviewDialog").then((m) => ({ default: m.PdfPreviewDialog })),
);

export const Route = createFileRoute("/soumission/$id")({
  head: () => ({ meta: [{ title: "Soumission — Éditer" }] }),
  component: Editor,
});

type Soumission = Tables<"soumissions">;

function emptyState(): FormState {
  return {
    client_nom: "",
    client_adresse: "",
    projet_adresse: "",
    date_soumission: new Date().toISOString().slice(0, 10),
    description: "",
    pieds_lineaires: 0,
    cheminees: 0,
    pompes: 0,
    drain_gouttiere: false,
    amenagement: "non_inclus",
    amenagement_precision: "",
    notes: "",
    sous_total: 0,
    travaux_custom: "",
    prix_custom: "",
    statut: "Brouillon",
    numero: "",
    modalites: DEFAULT_MODALITES,
    articles: [],
    sections: {},
  };
}

function Editor() {
  const { id } = Route.useParams();
  const { user, loading } = useAuth({ ensureAnonymous: true });
  const navigate = useNavigate();
  const isNew = id === "nouvelle";

  const [form, setForm] = useState<FormState>(emptyState());
  const [loaded, setLoaded] = useState(isNew);
  const [savedId, setSavedId] = useState<string | null>(isNew ? null : id);
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const [busy, setBusy] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [confirmDup, setConfirmDup] = useState(false);
  const [confirmSend, setConfirmSend] = useState(false);
  const [pdfOpen, setPdfOpen] = useState(false);
  const [pdfSoumission, setPdfSoumission] = useState<Soumission | null>(null);
  const [parent, setParent] = useState<{ id: string; client_nom: string; numero: string | null; date_soumission: string } | null>(null);
  const [children, setChildren] = useState<{ id: string; client_nom: string; date_soumission: string; statut: Soumission["statut"] }[]>([]);
  const [duplicatedAt, setDuplicatedAt] = useState<string | null>(null);

  useEffect(() => {
    if (isNew || !user) return;
    (async () => {
      const { data, error } = await supabase.from("soumissions").select("*").eq("id", id).single();
      if (error) { toast.error(error.message); navigate({ to: "/" }); return; }
      const s = data as Soumission;
      setForm({
        client_nom: s.client_nom,
        client_adresse: s.client_adresse,
        projet_adresse: s.projet_adresse,
        date_soumission: s.date_soumission,
        description: s.description,
        pieds_lineaires: s.pieds_lineaires,
        cheminees: s.cheminees,
        pompes: s.pompes,
        drain_gouttiere: s.drain_gouttiere,
        amenagement: s.amenagement,
        amenagement_precision: s.amenagement_precision ?? "",
        notes: s.notes ?? "",
        sous_total: Number(s.sous_total),
        travaux_custom: s.travaux_custom ?? "",
        prix_custom: s.prix_custom ?? "",
        statut: s.statut,
        numero: s.numero ?? "",
        modalites: (s.modalites as unknown as Modalite[]) ?? DEFAULT_MODALITES,
        articles: (s.articles as unknown as Article[]) ?? [],
        sections: ((s as unknown as { sections?: Record<string, string> }).sections ?? {}) as FormState["sections"],
      });
      setLoaded(true);
    })();
  }, [id, isNew, user, navigate, reloadKey]);

  // Load lineage (parent + children) for an existing soumission
  useEffect(() => {
    if (isNew || !user || !savedId) return;
    (async () => {
      const { data: cur } = await supabase
        .from("soumissions")
        .select("duplicated_from, duplicated_at")
        .eq("id", savedId)
        .single();
      setDuplicatedAt(cur?.duplicated_at ?? null);
      if (cur?.duplicated_from) {
        const { data: p } = await supabase
          .from("soumissions")
          .select("id, client_nom, numero, date_soumission")
          .eq("id", cur.duplicated_from)
          .maybeSingle();
        setParent(p ?? null);
      } else setParent(null);

      const { data: kids } = await supabase
        .from("soumissions")
        .select("id, client_nom, date_soumission, statut, duplicated_at")
        .eq("duplicated_from", savedId)
        .order("duplicated_at", { ascending: false });
      setChildren((kids as typeof children) ?? []);
    })();
  }, [savedId, isNew, user, reloadKey]);

  const previewSoumission: Soumission = useMemo(
    () => ({
      id: savedId ?? "preview",
      user_id: user?.id ?? "",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      client_nom: form.client_nom ?? "",
      client_adresse: form.client_adresse ?? "",
      projet_adresse: form.projet_adresse ?? "",
      date_soumission: form.date_soumission ?? new Date().toISOString().slice(0, 10),
      description: form.description ?? "",
      pieds_lineaires: form.pieds_lineaires ?? 0,
      cheminees: form.cheminees ?? 0,
      pompes: form.pompes ?? 0,
      drain_gouttiere: !!form.drain_gouttiere,
      amenagement: form.amenagement ?? "non_inclus",
      amenagement_precision: form.amenagement_precision ?? "",
      notes: form.notes ?? "",
      sous_total: Number(form.sous_total ?? 0),
      travaux_custom: form.travaux_custom ?? "",
      prix_custom: form.prix_custom ?? "",
      modalites: form.modalites as unknown as Soumission["modalites"],
      articles: form.articles as unknown as Soumission["articles"],
      sections: form.sections as unknown as Soumission["sections"],
      statut: form.statut ?? "Brouillon",
      numero: form.numero ?? null,
      entrepreneur_nom: form.entrepreneur_nom ?? null,
      entrepreneur_signature: form.entrepreneur_signature ?? null,
      entrepreneur_signed_at: form.entrepreneur_signed_at ?? null,
      client_signataire_nom: form.client_signataire_nom ?? null,
      client_signature: form.client_signature ?? null,
      client_signed_at: form.client_signed_at ?? null,
      sent_at: form.sent_at ?? null,
      duplicated_from: null,
      duplicated_at: null,
      signing_token: null,
    }),
    [form, savedId, user],
  );

  if (!isNew && (loading || !loaded)) {
    return (
      <AppShell>
        <div className="flex min-h-[40vh] flex-col items-center justify-center gap-3 text-sm text-muted-foreground">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          Chargement de la soumission…
        </div>
      </AppShell>
    );
  }

  if (!loading && !user) {
    return (
      <AppShell>
        <div className="mx-auto flex min-h-[40vh] max-w-md flex-col items-center justify-center gap-4 text-center">
          <div>
            <h1 className="text-xl font-semibold tracking-tight">Connexion requise</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              La session n'a pas pu être créée automatiquement. Connectez-vous pour créer une soumission.
            </p>
          </div>
          <Button asChild>
            <Link to="/auth">Se connecter</Link>
          </Button>
        </div>
      </AppShell>
    );
  }

  const validateDraft = (): string | null => {
    // Draft is intentionally permissive: allow saving partial work.
    // Full validation runs on "Marquer envoyée" via validateForSend.
    return null;
  };

  const save = async (
    statut?: Soumission["statut"],
    extra?: Partial<TablesInsert<"soumissions">>,
  ): Promise<Soumission | null> => {
    if (!user) {
      toast.error("Session en cours de préparation. Réessayez dans un instant.");
      return null;
    }
    const err = validateDraft();
    if (err) { toast.error(err); return null; }
    const current = form.statut ?? "Brouillon";
    const target = statut ?? current;
    if (target !== current && !canTransition(current, target)) {
      toast.error(`Transition non autorisée : ${current} → ${target}`);
      return null;
    }
    setBusy(true);
    const payload: TablesInsert<"soumissions"> = {
      ...form,
      ...extra,
      modalites: form.modalites as unknown as TablesInsert<"soumissions">["modalites"],
      articles: form.articles as unknown as TablesInsert<"soumissions">["articles"],
      statut: target,
      user_id: user.id,
    };
    let res;
    if (savedId) {
      res = await supabase.from("soumissions").update(payload).eq("id", savedId).select().single();
    } else {
      res = await supabase.from("soumissions").insert(payload).select().single();
    }
    setBusy(false);
    if (res.error) { toast.error(res.error.message); return null; }
    const saved = res.data as Soumission;
    // Recompute statut based on signatures + sent_at to keep DB in sync
    const computed = computeStatut(saved);
    if (computed !== saved.statut) {
      const r = await supabase.from("soumissions").update({ statut: computed }).eq("id", saved.id).select().single();
      if (!r.error) Object.assign(saved, r.data);
    }
    setSavedId(saved.id);
    setForm((f) => ({ ...f, statut: saved.statut, numero: saved.numero ?? f.numero ?? "" }));
    toast.success("Sauvegardé");
    if (!savedId) navigate({ to: "/soumission/$id", params: { id: saved.id }, replace: true });
    return saved;
  };

  const onPdf = async () => {
    const saved = await save();
    if (saved) {
      setPdfSoumission(saved);
      setPdfOpen(true);
    }
  };

  const onMarkSent = async () => {
    const err = validateForSend(form);
    if (err) { toast.error(err); return; }
    if (!canTransition(form.statut ?? "Brouillon", "Envoyée")) {
      toast.error("Cette soumission ne peut pas être marquée envoyée depuis son statut actuel.");
      return;
    }
    await save("Envoyée", { sent_at: new Date().toISOString() });
  };

  const onReopenDraft = async () => {
    if (!canTransition(form.statut ?? "Brouillon", "Brouillon")) {
      toast.error("Une soumission acceptée ou signée ne peut pas être remise en brouillon.");
      return;
    }
    await save("Brouillon", { sent_at: null });
  };

  const onCopySigningLink = async () => {
    if (!savedId) {
      toast.error("Sauvegardez d'abord la soumission.");
      return;
    }
    if (form.statut === "Brouillon") {
      const err = validateForSend(form);
      if (err) { toast.error(err); return; }
      await save("Envoyée", { sent_at: new Date().toISOString() });
    }
    const { data, error } = await supabase
      .from("soumissions")
      .select("signing_token")
      .eq("id", savedId)
      .single();
    if (error || !data?.signing_token) {
      toast.error("Impossible de récupérer le lien de signature.");
      return;
    }
    const url = `${window.location.origin}/signer/${data.signing_token}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Lien copié — partagez-le avec le client.", { description: url });
    } catch {
      window.prompt("Copiez le lien :", url);
    }
  };

  const onDuplicate = async () => {
    if (!user) {
      toast.error("Session en cours de préparation. Réessayez dans un instant.");
      return;
    }
    // Persist current edits first so the copy reflects what's on screen.
    if (savedId) await save();
    setBusy(true);
    const base: TablesInsert<"soumissions"> = {
      ...form,
      modalites: form.modalites as unknown as TablesInsert<"soumissions">["modalites"],
      articles: form.articles as unknown as TablesInsert<"soumissions">["articles"],
      user_id: user.id,
      statut: "Brouillon",
      numero: null,
      sent_at: null,
      entrepreneur_signature: null,
      entrepreneur_signed_at: null,
      entrepreneur_nom: null,
      client_signature: null,
      client_signed_at: null,
      client_signataire_nom: null,
      date_soumission: new Date().toISOString().slice(0, 10),
      duplicated_from: savedId,
      duplicated_at: new Date().toISOString(),
    };
    const { data, error } = await supabase.from("soumissions").insert(base).select().single();
    setBusy(false);
    if (error || !data) { toast.error(error?.message ?? "Erreur"); return; }
    const copy = data as Soumission;
    toast.success("Soumission dupliquée", {
      description: (
        <div className="space-y-0.5 text-xs">
          <div><span className="text-muted-foreground">Client :</span> <strong>{copy.client_nom || "(sans nom)"}</strong></div>
          <div><span className="text-muted-foreground">N° :</span> {copy.numero ?? `#${copy.id.slice(0, 8)}`}</div>
          <div><span className="text-muted-foreground">Statut :</span> Brouillon</div>
          <div className="pt-1 italic text-muted-foreground">Ouverture de la copie…</div>
        </div>
      ),
      duration: 2500,
    });
    setTimeout(() => navigate({ to: "/soumission/$id", params: { id: copy.id } }), 600);
  };

  const statutVariant: Record<Soumission["statut"], "secondary" | "default" | "outline"> = {
    Brouillon: "outline",
    Envoyée: "secondary",
    Acceptée: "default",
    Signée: "default",
  };

  return (
    <AppShell>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/"><ArrowLeft className="mr-2 h-4 w-4" />Retour</Link>
          </Button>
          {savedId && (
            <Badge variant={statutVariant[form.statut ?? "Brouillon"]}>{form.statut}</Badge>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          {mode === "edit" ? (
            <Button variant="outline" onClick={() => setMode("preview")}><Eye className="mr-2 h-4 w-4" />Prévisualiser</Button>
          ) : (
            <Button variant="outline" onClick={() => setMode("edit")}><Pencil className="mr-2 h-4 w-4" />Modifier</Button>
          )}
          <Button variant="secondary" disabled={busy || !user} onClick={() => save("Brouillon")}>
            <Save className="mr-2 h-4 w-4" />Sauvegarder
          </Button>
          {savedId && (
            <AlertDialog open={confirmDup} onOpenChange={setConfirmDup}>
              <AlertDialogTrigger asChild>
                <Button variant="outline" disabled={busy}>
                  <Copy className="mr-2 h-4 w-4" />Dupliquer
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Dupliquer cette soumission ?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Une copie sera créée comme <strong>Brouillon</strong> pour le client
                    « {form.client_nom || "(sans nom)"} », sans signatures ni date d'envoi,
                    avec la date d'aujourd'hui. Vous serez redirigé vers la copie.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Annuler</AlertDialogCancel>
                  <AlertDialogAction onClick={onDuplicate}>Dupliquer</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          {savedId && form.statut === "Brouillon" && (
            <AlertDialog open={confirmSend} onOpenChange={setConfirmSend}>
              <AlertDialogTrigger asChild>
                <Button variant="default" disabled={busy}>
                  <Send className="mr-2 h-4 w-4" />Marquer envoyée
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Marquer la soumission comme envoyée ?</AlertDialogTitle>
                  <AlertDialogDescription asChild>
                    {(() => {
                      const missing = listMissingForSend(form);
                      return missing.length === 0 ? (
                        <span className="flex items-start gap-2 text-sm">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 text-primary" />
                          <span>
                            Tous les champs requis sont remplis. La soumission passera au statut
                            <strong> Envoyée</strong> et la date d'envoi sera enregistrée.
                          </span>
                        </span>
                      ) : (
                        <span className="block space-y-2 text-sm">
                          <span className="flex items-center gap-2 font-medium text-destructive">
                            <AlertCircle className="h-4 w-4" />
                            {missing.length} champ{missing.length > 1 ? "s" : ""} à compléter avant l'envoi :
                          </span>
                          <ul className="ml-6 list-disc space-y-1 text-foreground">
                            {missing.map((m) => (<li key={m}>{m}</li>))}
                          </ul>
                          <span className="block pt-1 text-xs text-muted-foreground">
                            Complétez ces éléments dans le formulaire, puis réessayez.
                          </span>
                        </span>
                      );
                    })()}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Annuler</AlertDialogCancel>
                  <AlertDialogAction
                    disabled={listMissingForSend(form).length > 0}
                    onClick={onMarkSent}
                  >
                    Marquer envoyée
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          {savedId && form.statut === "Envoyée" && (
            <Button variant="outline" disabled={busy} onClick={onReopenDraft}>
              <RotateCcw className="mr-2 h-4 w-4" />Remettre en brouillon
            </Button>
          )}
          {savedId && form.statut !== "Signée" && (
            <Button variant="outline" disabled={busy} onClick={onCopySigningLink}>
              <Link2 className="mr-2 h-4 w-4" />Lien de signature
            </Button>
          )}
          <Button disabled={busy || !user} onClick={onPdf}>
            <FileDown className="mr-2 h-4 w-4" />Générer PDF
          </Button>
        </div>
      </div>

      {pdfOpen && (
        <Suspense fallback={null}>
          <PdfPreviewDialog
            soumission={pdfSoumission}
            open={pdfOpen}
            onOpenChange={(v) => { setPdfOpen(v); if (!v) setPdfSoumission(null); }}
          />
        </Suspense>
      )}

      <h1 className="mb-2 text-2xl font-bold tracking-tight">
        {isNew && !savedId ? "Nouvelle soumission-contrat" : `Soumission — ${form.client_nom || "(sans nom)"}`}
      </h1>

      {(parent || children.length > 0) && (
        <div className="mb-4 rounded-md border bg-muted/30 p-3 text-xs">
          <div className="mb-1 flex items-center gap-2 font-semibold uppercase tracking-wide text-muted-foreground">
            <GitBranch className="h-3.5 w-3.5" />Historique de duplication
          </div>
          {parent && (
            <div>
              Copie de{" "}
              <Link
                to="/soumission/$id"
                params={{ id: parent.id }}
                className="font-medium text-primary underline-offset-2 hover:underline"
              >
                {parent.client_nom || "(sans nom)"}
                {parent.numero ? ` — N° ${parent.numero}` : ""}
              </Link>
              {duplicatedAt && (
                <span className="text-muted-foreground"> · {new Date(duplicatedAt).toLocaleString("fr-CA")}</span>
              )}
            </div>
          )}
          {children.length > 0 && (
            <div className="mt-1">
              <span className="text-muted-foreground">Copies créées ({children.length}) : </span>
              {children.map((c, i) => (
                <span key={c.id}>
                  {i > 0 && ", "}
                  <Link
                    to="/soumission/$id"
                    params={{ id: c.id }}
                    className="text-primary underline-offset-2 hover:underline"
                  >
                    {c.client_nom || "(sans nom)"} — {new Date(c.date_soumission).toLocaleDateString("fr-CA")} ({c.statut})
                  </Link>
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {mode === "edit" ? (
        <>
          <SoumissionForm value={form} onChange={setForm} />
          {user && (
            <div className="mt-6">
              <SignaturesSection soumissionId={savedId} userId={user.id} />
            </div>
          )}
          <div className="sticky bottom-2 z-10 mt-6 flex flex-wrap justify-end gap-2 rounded-md border bg-background/95 p-3 shadow-md backdrop-blur">
            <Button variant="secondary" disabled={busy || !user} onClick={() => save("Brouillon")}>
              <Save className="mr-2 h-4 w-4" />Sauvegarder
            </Button>
            <Button disabled={busy || !user} onClick={onPdf}>
              <FileDown className="mr-2 h-4 w-4" />Générer PDF
            </Button>
          </div>
        </>
      ) : (
        <SoumissionPreview
          s={previewSoumission}
          signable={!!savedId && !!user}
          userId={user?.id ?? ""}
          onSigned={() => setReloadKey((k) => k + 1)}
        />
      )}
    </AppShell>
  );
}