import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { FileText, Sparkles, Zap, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Soumissions — Mini Excavation Érable" }] }),
  component: Landing,
});

function Landing() {
  return (
    <AppShell>
      <div className="flex flex-col items-center gap-10 py-8 text-center">
        <a
          href="https://connek.io"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs font-medium text-primary transition hover:bg-primary/10"
        >
          <Sparkles className="h-3.5 w-3.5" />
          Powered by <span className="font-bold tracking-wide">CONNEK</span>
        </a>

        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
            Mini Excavation Érable Inc.
          </h1>
          <p className="mx-auto max-w-xl text-base text-muted-foreground">
            Créez et gérez vos soumissions-contrats en quelques clics.
          </p>
        </div>

        <Button size="lg" asChild>
          <Link to="/soumission/$id" params={{ id: "nouvelle" }}>
            <FileText className="mr-2 h-5 w-5" />Soumission
          </Link>
        </Button>

        <section className="mt-8 w-full max-w-3xl rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-background p-6 sm:p-8">
          <div className="mb-4 flex flex-col items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-primary">
              <Sparkles className="h-3 w-3" /> CONNEK
            </span>
            <h2 className="text-2xl font-bold tracking-tight">
              Cet outil est <span className="text-primary">propulsé par CONNEK</span>
            </h2>
            <p className="max-w-xl text-sm text-muted-foreground">
              CONNEK conçoit des outils numériques sur mesure pour les entrepreneurs québécois :
              soumissions, contrats, signatures électroniques et automatisations.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-lg border border-border/60 bg-background/60 p-3 text-left">
              <Zap className="mb-1.5 h-4 w-4 text-primary" />
              <div className="text-sm font-semibold">Rapide à déployer</div>
              <div className="text-xs text-muted-foreground">Prêt en quelques jours, adapté à votre métier.</div>
            </div>
            <div className="rounded-lg border border-border/60 bg-background/60 p-3 text-left">
              <ShieldCheck className="mb-1.5 h-4 w-4 text-primary" />
              <div className="text-sm font-semibold">Données sécurisées</div>
              <div className="text-xs text-muted-foreground">Hébergement infonuagique fiable et chiffré.</div>
            </div>
            <div className="rounded-lg border border-border/60 bg-background/60 p-3 text-left">
              <Sparkles className="mb-1.5 h-4 w-4 text-primary" />
              <div className="text-sm font-semibold">Sur mesure</div>
              <div className="text-xs text-muted-foreground">Conçu autour de votre flux de travail réel.</div>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
            <Button asChild variant="default">
              <a href="https://connek.io" target="_blank" rel="noopener noreferrer">
                Découvrir CONNEK
              </a>
            </Button>
            <a
              href="mailto:hello@connek.io"
              className="text-xs font-medium text-muted-foreground underline-offset-4 hover:text-primary hover:underline"
            >
              hello@connek.io
            </a>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
