import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { SoumissionPreview } from "@/components/app/SoumissionPreview";
import { SignaturePad, type SignaturePadHandle } from "@/components/app/SignaturePad";
import { acceptAndSignByToken, getSoumissionByToken } from "@/lib/signing.functions";
import { CheckCircle2, Eraser, PenLine, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import type { Soumission } from "@/lib/contract-text";

export const Route = createFileRoute("/signer/$token")({
  head: () => ({
    meta: [
      { title: "Signer la soumission" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: SignerPage,
});

function SignerPage() {
  const { token } = Route.useParams();
  const router = useRouter();
  const fetchByToken = useServerFn(getSoumissionByToken);
  const signFn = useServerFn(acceptAndSignByToken);

  const { data, isLoading, error } = useQuery({
    queryKey: ["signer", token],
    queryFn: () => fetchByToken({ data: { token } }),
    retry: false,
  });

  const [open, setOpen] = useState(false);
  const [nom, setNom] = useState("");
  const [busy, setBusy] = useState(false);
  const padRef = useRef<SignaturePadHandle>(null);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted/30 px-6 text-sm text-muted-foreground">
        Chargement de la soumission…
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-muted/30 px-6 text-center">
        <h1 className="text-xl font-semibold">Lien invalide</h1>
        <p className="max-w-md text-sm text-muted-foreground">
          {(error as Error | null)?.message ??
            "Ce lien de signature est introuvable ou a expiré. Demandez un nouveau lien à l'entrepreneur."}
        </p>
      </div>
    );
  }

  const s = data.soumission as unknown as Soumission;
  const alreadySigned = !!s.client_signature;

  const onSubmit = async () => {
    if (!nom.trim() || nom.trim().length < 2) {
      toast.error("Entrez votre nom complet (min. 2 caractères).");
      return;
    }
    if (padRef.current?.isEmpty()) {
      toast.error("Veuillez signer dans la zone prévue.");
      return;
    }
    setBusy(true);
    try {
      const dataUrl = padRef.current!.toDataURL();
      await signFn({
        data: {
          token,
          nom: nom.trim(),
          signature_data: dataUrl,
          user_agent: typeof navigator !== "undefined" ? navigator.userAgent : null,
        },
      });
      toast.success("Soumission acceptée et signée. Merci !");
      setOpen(false);
      router.invalidate();
    } catch (e) {
      toast.error((e as Error).message ?? "Erreur lors de la signature.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30 pb-16">
      <header className="border-b bg-card px-4 py-3 sm:px-6">
        <div className="mx-auto flex max-w-3xl flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm">
            <ShieldCheck className="h-4 w-4 text-primary" />
            <span className="font-medium">Soumission à signer</span>
            {s.numero && <Badge variant="outline">N° {s.numero}</Badge>}
          </div>
          {alreadySigned ? (
            <Badge variant="default" className="gap-1">
              <CheckCircle2 className="h-3.5 w-3.5" /> Signée
            </Badge>
          ) : (
            <Button onClick={() => setOpen(true)}>
              <PenLine className="mr-2 h-4 w-4" />
              Accepter et signer
            </Button>
          )}
        </div>
      </header>

      <main className="mx-auto mt-4 max-w-3xl px-2 sm:px-4">
        <SoumissionPreview s={s} />
      </main>

      {!alreadySigned && (
        <div className="fixed inset-x-0 bottom-0 border-t bg-card/95 px-4 py-3 backdrop-blur sm:hidden">
          <Button className="w-full" size="lg" onClick={() => setOpen(true)}>
            <PenLine className="mr-2 h-4 w-4" />
            Accepter et signer
          </Button>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Accepter et signer la soumission</DialogTitle>
            <DialogDescription>
              En signant, vous acceptez les travaux, les exclusions et les modalités décrites
              dans cette soumission.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="nom">Nom complet</Label>
              <Input
                id="nom"
                value={nom}
                onChange={(e) => setNom(e.target.value)}
                placeholder="Prénom Nom"
                autoComplete="name"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Signature</Label>
              <SignaturePad ref={padRef} />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => padRef.current?.clear()}
              >
                <Eraser className="mr-2 h-4 w-4" /> Effacer
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)} disabled={busy}>
              Annuler
            </Button>
            <Button onClick={onSubmit} disabled={busy}>
              <PenLine className="mr-2 h-4 w-4" />
              {busy ? "Envoi…" : "Accepter et signer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}