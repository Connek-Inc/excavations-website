export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      profiles: {
        Row: {
          created_at: string
          email: string | null
          id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
        }
        Relationships: []
      }
      signatures: {
        Row: {
          created_at: string
          id: string
          ip_address: string | null
          nom_signataire: string
          role: Database["public"]["Enums"]["signature_role"]
          signature_data: string
          signed_at: string
          soumission_id: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          ip_address?: string | null
          nom_signataire: string
          role: Database["public"]["Enums"]["signature_role"]
          signature_data: string
          signed_at?: string
          soumission_id: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          ip_address?: string | null
          nom_signataire?: string
          role?: Database["public"]["Enums"]["signature_role"]
          signature_data?: string
          signed_at?: string
          soumission_id?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "signatures_soumission_id_fkey"
            columns: ["soumission_id"]
            isOneToOne: false
            referencedRelation: "soumissions"
            referencedColumns: ["id"]
          },
        ]
      }
      soumissions: {
        Row: {
          amenagement: Database["public"]["Enums"]["amenagement_type"]
          amenagement_precision: string | null
          articles: Json
          cheminees: number
          client_adresse: string
          client_nom: string
          client_signataire_nom: string | null
          client_signature: string | null
          client_signed_at: string | null
          created_at: string
          date_soumission: string
          description: string
          drain_gouttiere: boolean
          duplicated_at: string | null
          duplicated_from: string | null
          entrepreneur_nom: string | null
          entrepreneur_signature: string | null
          entrepreneur_signed_at: string | null
          id: string
          modalites: Json
          notes: string | null
          numero: string | null
          pieds_lineaires: number
          pompes: number
          prix_custom: string | null
          projet_adresse: string
          sections: Json
          sent_at: string | null
          signing_token: string | null
          sous_total: number
          statut: Database["public"]["Enums"]["soumission_statut"]
          travaux_custom: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amenagement?: Database["public"]["Enums"]["amenagement_type"]
          amenagement_precision?: string | null
          articles?: Json
          cheminees?: number
          client_adresse?: string
          client_nom?: string
          client_signataire_nom?: string | null
          client_signature?: string | null
          client_signed_at?: string | null
          created_at?: string
          date_soumission?: string
          description?: string
          drain_gouttiere?: boolean
          duplicated_at?: string | null
          duplicated_from?: string | null
          entrepreneur_nom?: string | null
          entrepreneur_signature?: string | null
          entrepreneur_signed_at?: string | null
          id?: string
          modalites?: Json
          notes?: string | null
          numero?: string | null
          pieds_lineaires?: number
          pompes?: number
          prix_custom?: string | null
          projet_adresse?: string
          sections?: Json
          sent_at?: string | null
          signing_token?: string | null
          sous_total?: number
          statut?: Database["public"]["Enums"]["soumission_statut"]
          travaux_custom?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amenagement?: Database["public"]["Enums"]["amenagement_type"]
          amenagement_precision?: string | null
          articles?: Json
          cheminees?: number
          client_adresse?: string
          client_nom?: string
          client_signataire_nom?: string | null
          client_signature?: string | null
          client_signed_at?: string | null
          created_at?: string
          date_soumission?: string
          description?: string
          drain_gouttiere?: boolean
          duplicated_at?: string | null
          duplicated_from?: string | null
          entrepreneur_nom?: string | null
          entrepreneur_signature?: string | null
          entrepreneur_signed_at?: string | null
          id?: string
          modalites?: Json
          notes?: string | null
          numero?: string | null
          pieds_lineaires?: number
          pompes?: number
          prix_custom?: string | null
          projet_adresse?: string
          sections?: Json
          sent_at?: string | null
          signing_token?: string | null
          sous_total?: number
          statut?: Database["public"]["Enums"]["soumission_statut"]
          travaux_custom?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "soumissions_duplicated_from_fkey"
            columns: ["duplicated_from"]
            isOneToOne: false
            referencedRelation: "soumissions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      amenagement_type: "non_inclus" | "inclus" | "partiellement" | "a_preciser"
      signature_role: "client" | "entrepreneur"
      soumission_statut: "Brouillon" | "Envoyée" | "Acceptée" | "Signée"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      amenagement_type: ["non_inclus", "inclus", "partiellement", "a_preciser"],
      signature_role: ["client", "entrepreneur"],
      soumission_statut: ["Brouillon", "Envoyée", "Acceptée", "Signée"],
    },
  },
} as const
